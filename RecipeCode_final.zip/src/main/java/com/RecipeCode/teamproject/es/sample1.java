package com.RecipeCode.teamproject.es;

public class sample1 {
}
