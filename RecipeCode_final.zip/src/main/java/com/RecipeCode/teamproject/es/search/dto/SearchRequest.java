package com.RecipeCode.teamproject.es.search.dto;

public class SearchRequest {
}
