package com.RecipeCode.teamproject.es.dashboard.dto;

public class ReportStatusDto {
}
