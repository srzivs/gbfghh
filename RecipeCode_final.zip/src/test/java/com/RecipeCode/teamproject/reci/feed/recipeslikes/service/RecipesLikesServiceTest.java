package com.RecipeCode.teamproject.reci.feed.recipeslikes.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RecipesLikesServiceTest {

    @Test
    void toggleLike() {
    }
}